var mysql  = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database:"projet_pfe"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected OK!");
});
con.query(`select * from  societe` , (err,result) => {
    if(err)
      {  return console.log(err); }

      return console.log(result);
})
